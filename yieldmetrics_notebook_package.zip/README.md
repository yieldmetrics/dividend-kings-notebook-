# Dividend Kings Notebook

This Jupyter notebook uses Yahoo Finance data to analyze Dividend Kings and estimate the year they joined the 50+ dividend growth club.